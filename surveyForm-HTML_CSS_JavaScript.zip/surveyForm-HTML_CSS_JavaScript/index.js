function handleForm(){
    let input1=document.querySelector("#username").value
    let input2=document.querySelector("#email").value;
    let input3=document.querySelector("#phone").value;
    let input4=document.querySelector("#age").value;
    let input5=document.querySelector("#location").value;
    let input6=document.querySelector("#deliveryexp").value;
    let input7=document.querySelector("#intime").value;
    let input8=document.querySelector("#productcond").value;
    let input9=document.querySelector("#pakagingquality").value;
    let input10=document.querySelector("#isscratch").value;
    let input11=document.querySelector("#expectation").value;
    let input12=document.querySelector("#isdifferent").value;
    let input13=document.querySelector("#productquality").value;
    let input14=document.querySelector("#iscoopon").value;
    let input15=document.querySelector("#isdiscount").value;
    let input16=document.querySelector("#isreturn").value;
    let input17=document.querySelector("#reasonofreturn").value;
    let input18=document.querySelector("#isfilled").value;
    let input19=document.querySelector("#timesoffilling").value;
    let input20=document.querySelector("#rating").value;
    let data={}
    data.username=input1;
    data.email=input2;
    data.phone=input3;
    data.age=input4;
    data.location=input5;
    data.deliveryexp=input6;
    data.intime=input7;
    data.productcond=input8;
    data.pakagingquality=input9;
    data.isscratch=input10;
    data.expectation=input11;
    data.isdifferent=input12;
    data.productquality=input13;
    data.iscoopon=input14;
    data.isdiscount=input15;
    data.isreturn=input16;
    data.reasonofreturn=input17;
    data.isfilled=input18;
    data.timesoffilling=input19;
    data.rating=input20;

    // console.log(input1)
    // console.log(input10)
    // console.log(input11)
    // console.log(input12)
    // console.log(input13)
    // console.log(input14)
    // console.log(input15)
    // console.log(input16)
    // console.log(input17)
    // console.log(data)
}